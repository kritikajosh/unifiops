"use client"

import { useMemo, useState } from "react"
import {
  Search,
  FileText,
  Check,
  X,
  RotateCcw,
  Download,
  Sparkles,
  ChevronRight,
  Paperclip,
} from "lucide-react"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { StatusBadge, VerificationBadge } from "@/components/status-badge"
import {
  businessQueue,
  workflowFields,
  formatCurrency,
  type BusinessRequest,
  type WorkflowKey,
} from "@/lib/business-data"
import type { RequestStatus } from "@/lib/types"
import { SourceBadge } from "@/components/status-badge"
import { cn } from "@/lib/utils"

type Filter = "all" | "needs-action" | RequestStatus

const filters: { key: Filter; label: string }[] = [
  { key: "all", label: "All" },
  { key: "needs-action", label: "Needs action" },
  { key: "submitted", label: "New" },
  { key: "ai-verified", label: "Automated" },
  { key: "employee-review", label: "In review" },
  { key: "approved", label: "Approved" },
  { key: "rejected", label: "Rejected" },
]

const workflowToKey: Record<string, WorkflowKey> = {
  "Expense Claim": "expense",
  "Invoice Submission": "invoice",
  "Purchase Request": "purchase",
  "Vendor Registration": "vendor",
  "Purchase Order Request": "po",
}

export function AdminConsole() {
  const [filter, setFilter] = useState<Filter>("all")
  const [query, setQuery] = useState("")
  const [selected, setSelected] = useState<BusinessRequest | null>(null)

  const rows = useMemo(() => {
    return businessQueue.filter((r) => {
      const matchFilter =
        filter === "all" ? true : filter === "needs-action" ? r.needsAction : r.status === filter
      const matchQuery =
        query.trim() === "" ||
        `${r.id} ${r.submitter} ${r.workflow}`.toLowerCase().includes(query.toLowerCase())
      return matchFilter && matchQuery
    })
  }, [filter, query])

  return (
    <div className="grid gap-5 lg:grid-cols-3">
      <div className={cn("space-y-4", selected ? "lg:col-span-2" : "lg:col-span-3")}>
        <Card className="p-4 sm:p-5">
          {/* Controls */}
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div className="relative w-full sm:max-w-xs">
              <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search requests, people…"
                className="w-full rounded-lg border border-input bg-card py-2 pl-9 pr-3 text-sm outline-none ring-ring/40 transition focus:border-ring focus:ring-2"
              />
            </div>
            <Button variant="outline" size="sm">
              <Download className="size-4" />
              Generate report
            </Button>
          </div>

          <div className="mt-4 flex flex-wrap gap-2">
            {filters.map((f) => (
              <button
                key={f.key}
                onClick={() => setFilter(f.key)}
                className={cn(
                  "rounded-full border px-3 py-1 text-xs font-medium transition-colors",
                  filter === f.key
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-muted-foreground hover:text-foreground",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>

          {/* Table */}
          <div className="mt-4 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs text-muted-foreground">
                  <th className="pb-2 font-medium">Request</th>
                  <th className="pb-2 font-medium">Workflow</th>
                  <th className="hidden pb-2 font-medium md:table-cell">Amount</th>
                  <th className="hidden pb-2 font-medium sm:table-cell">Automation</th>
                  <th className="pb-2 font-medium">Status</th>
                  <th className="pb-2" />
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr
                    key={r.id}
                    onClick={() => setSelected(r)}
                    className={cn(
                      "cursor-pointer border-b border-border/60 transition-colors hover:bg-muted/50",
                      selected?.id === r.id && "bg-muted/60",
                    )}
                  >
                    <td className="py-3">
                      <p className="font-medium">{r.id}</p>
                      <p className="text-xs text-muted-foreground">{r.submitter}</p>
                    </td>
                    <td className="py-3 text-muted-foreground">{r.workflow}</td>
                    <td className="hidden py-3 tabular-nums md:table-cell">
                      {r.amount > 0 ? formatCurrency(r.amount) : "—"}
                    </td>
                    <td className="hidden py-3 sm:table-cell">
                      <VerificationBadge state={r.automation} />
                    </td>
                    <td className="py-3">
                      <StatusBadge status={r.status} />
                    </td>
                    <td className="py-3 text-right">
                      <ChevronRight className="ml-auto size-4 text-muted-foreground" />
                    </td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr>
                    <td colSpan={6} className="py-10 text-center text-sm text-muted-foreground">
                      No requests match this view.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
      </div>

      {/* Review drawer */}
      {selected && (
        <div className="lg:col-span-1">
          <Card className="p-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="font-semibold">{selected.id}</p>
                <p className="text-xs text-muted-foreground">
                  {selected.workflow} · {selected.submitter}
                </p>
              </div>
              <button
                onClick={() => setSelected(null)}
                className="grid size-7 place-items-center rounded-md text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
                aria-label="Close"
              >
                <X className="size-4" />
              </button>
            </div>

            <div className="mt-4 flex items-center gap-2 rounded-lg bg-accent/8 p-3 text-xs">
              <Sparkles className="size-4 shrink-0 text-accent" />
              <span className="text-muted-foreground">
                Automation captured this from a {selected.documentType.toLowerCase()} — review the extracted fields
                below.
              </span>
            </div>

            <div className="mt-4">
              <p className="text-xs font-medium text-muted-foreground">Extracted information</p>
              <div className="mt-2 space-y-2.5">
                {(workflowFields[workflowToKey[selected.workflow]] ?? []).slice(0, 5).map((f) => (
                  <div key={f.key} className="flex items-center justify-between gap-3 text-sm">
                    <span className="text-muted-foreground">{f.label}</span>
                    <span className="flex items-center gap-2 text-right font-medium">
                      {f.value || <span className="text-warning-foreground">Needs input</span>}
                      <SourceBadge source={f.source} />
                    </span>
                  </div>
                ))}
              </div>
            </div>

            <button className="mt-4 inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:underline">
              <Paperclip className="size-3.5" />
              View supporting document
            </button>

            <div className="mt-5 grid grid-cols-2 gap-2">
              <Button size="sm" className="col-span-2">
                <Check className="size-4" />
                Approve
              </Button>
              <Button size="sm" variant="outline">
                <RotateCcw className="size-4" />
                Request fix
              </Button>
              <Button size="sm" variant="outline" className="text-destructive hover:text-destructive">
                <X className="size-4" />
                Reject
              </Button>
            </div>
          </Card>

          <Card className="mt-4 p-5">
            <div className="flex items-center gap-2">
              <FileText className="size-4 text-primary" />
              <p className="text-sm font-medium">Generated documents</p>
            </div>
            <p className="mt-2 text-xs text-muted-foreground">
              {selected.status === "approved"
                ? "Voucher and audit record filed automatically."
                : "Approving will generate the standardized document and record."}
            </p>
          </Card>
        </div>
      )}
    </div>
  )
}
