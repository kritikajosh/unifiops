import { Clock, CheckCircle2, XCircle, AlertTriangle, Layers, IndianRupee } from "lucide-react"
import { DashboardShell } from "@/components/dashboard-shell"
import { StatCard } from "@/components/dashboard/stat-card"
import { AdminConsole } from "@/components/business/admin-console"
import { Button } from "@/components/ui/button"
import { businessQueue, formatCompactCurrency } from "@/lib/business-data"

export default function BusinessAdminPage() {
  const pending = businessQueue.filter((r) =>
    ["submitted", "ai-verified", "employee-review"].includes(r.status),
  ).length
  const approved = businessQueue.filter((r) => r.status === "approved").length
  const rejected = businessQueue.filter((r) => r.status === "rejected").length
  const needsAction = businessQueue.filter((r) => r.needsAction).length
  const totalProcessed = 1284
  const totalAmount = businessQueue.reduce((s, r) => s + r.amount, 0) + 4_120_000

  return (
    <DashboardShell
      sector="Business"
      role="Admin"
      roleName="Operations Control"
      roleInitials="OC"
      nav="business"
      breadcrumb={["Business", "Admin", "Operations"]}
      title="Operations overview"
      subtitle="Every request here started as a document — captured once, then turned into records automatically."
      actions={
        <>
          <Button variant="outline">Last 7 days</Button>
          <Button>Generate report</Button>
        </>
      }
    >
      <div className="mb-6 grid gap-4 grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <StatCard label="Pending" value={pending} icon={Clock} tone="warning" />
        <StatCard label="Approved" value={approved} icon={CheckCircle2} tone="success" />
        <StatCard label="Rejected" value={rejected} icon={XCircle} tone="destructive" />
        <StatCard label="Needs action" value={needsAction} icon={AlertTriangle} tone="warning" />
        <StatCard label="Total processed" value={totalProcessed.toLocaleString()} icon={Layers} />
        <StatCard label="Total amount" value={formatCompactCurrency(totalAmount)} icon={IndianRupee} tone="success" />
      </div>

      <AdminConsole />
    </DashboardShell>
  )
}
