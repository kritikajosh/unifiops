import { FileStack, Clock, CheckCircle2, XCircle } from "lucide-react"
import { DashboardShell } from "@/components/dashboard-shell"
import { StatCard } from "@/components/dashboard/stat-card"
import { OperationsView } from "@/components/admin/operations-view"
import { ActivityFeed, DepartmentBreakdown, CitizenActions } from "@/components/admin/side-panels"
import { Button } from "@/components/ui/button"
import { governmentRequests } from "@/lib/mock-data"

export default function GovernmentAdminPage() {
  const total = 1040
  const pending = governmentRequests.filter((r) => ["submitted", "ai-verified", "employee-review"].includes(r.status)).length + 128
  const approved = 857
  const rejected = 55

  const citizenActions = [
    { label: "QR scans today", value: 342, tone: "text-primary" },
    { label: "Documents uploaded", value: 318, tone: "text-accent-foreground" },
    { label: "Corrections resubmitted", value: 41, tone: "text-warning-foreground" },
    { label: "Notified", value: 289, tone: "text-success" },
  ]

  return (
    <DashboardShell
      sector="Government"
      role="Admin"
      roleName="Operations Control"
      roleInitials="OC"
      nav="government"
      breadcrumb={["Government", "Admin", "Operations"]}
      title="Operations Monitoring"
      subtitle="Live view across departments, services and the full request lifecycle."
      actions={
        <>
          <Button variant="outline">Last 7 days</Button>
          <Button>Export report</Button>
        </>
      }
    >
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total requests" value={total.toLocaleString()} icon={FileStack} trend={{ value: "+6.4%", up: true }} />
        <StatCard label="Pending" value={pending} icon={Clock} tone="warning" />
        <StatCard label="Approved" value={approved} icon={CheckCircle2} tone="success" trend={{ value: "+9%", up: true }} />
        <StatCard label="Rejected" value={rejected} icon={XCircle} tone="destructive" trend={{ value: "-2%", up: false }} />
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <OperationsView requests={governmentRequests} />
        </div>
        <div className="space-y-5">
          <CitizenActions items={citizenActions} />
          <DepartmentBreakdown />
        </div>
      </div>

      <div className="mt-5">
        <ActivityFeed />
      </div>
    </DashboardShell>
  )
}
