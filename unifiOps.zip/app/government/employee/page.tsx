import { Inbox, ShieldCheck, AlertTriangle, CheckCircle2 } from "lucide-react"
import { DashboardShell } from "@/components/dashboard-shell"
import { StatCard } from "@/components/dashboard/stat-card"
import { VerificationDesk } from "@/components/employee/verification-desk"
import { Button } from "@/components/ui/button"
import { governmentRequests } from "@/lib/mock-data"

export default function GovernmentEmployeePage() {
  const pending = governmentRequests.filter((r) => r.status === "ai-verified" || r.status === "employee-review").length
  const warnings = governmentRequests.filter((r) => r.verification === "warning" || r.verification === "failed").length

  return (
    <DashboardShell
      sector="Government"
      role="Employee"
      roleName="Meera Nair"
      roleInitials="MN"
      nav="government"
      breadcrumb={["Government", "Employee", "Verification Desk"]}
      title="Verification Desk"
      subtitle="Review AI-verified requests and make the final call. AI assists — you decide."
      actions={<Button variant="outline">Export queue</Button>}
    >
      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="In your queue" value={pending} icon={Inbox} />
        <StatCard label="AI-cleared today" value={18} icon={ShieldCheck} tone="success" trend={{ value: "+12%", up: true }} />
        <StatCard label="Needs attention" value={warnings} icon={AlertTriangle} tone="warning" />
        <StatCard label="Approved this week" value={64} icon={CheckCircle2} tone="success" trend={{ value: "+8%", up: true }} />
      </div>
      <VerificationDesk requests={governmentRequests} subjectLabel="Citizen" />
    </DashboardShell>
  )
}
